import urllib.request
import urllib.parse
import os
import sys





def main():
    webhook_url = sys.argv[1]
    message = {'content': 'New build available!'}
    files = {'file': open('archive.7z', 'rb')}

    boundary = '----WebKitFormBoundary7MA4YWxkTrZu0gW'
    data = prepare_data(message, files, boundary)

    send_request(webhook_url, data)



def prepare_data(message, files, boundary):
    payload = '\r\n'.join(f'Content-Disposition: form-data; name="{key}"\r\n\r\n{value}' for key, value in message.items())

    file_data = []
    for key, file_obj in files.items():
        file_info = file_obj.read()
        file_obj.close()
        filename = os.path.basename(file_obj.name)
        file_data.append(f'Content-Disposition: form-data; name="{key}"; filename="{filename}"\r\nContent-Type: application/octet-stream\r\n\r\n{file_info}')

    data = f'--{boundary}\r\n{payload}\r\n--{boundary}\r\n'.encode('utf-8')
    for item in file_data:
        data += f'{item}\r\n--{boundary}\r\n'.encode('utf-8')
    data += b'--\r\n'

    return data



def send_request(url, data):
    req = urllib.request.Request(url, data=data, headers={'Content-Type': f'multipart/form-data; boundary={boundary}'})
    with urllib.request.urlopen(req) as response:
        print(response.read().decode('utf-8'))



if __name__ == "__main__":
    main()